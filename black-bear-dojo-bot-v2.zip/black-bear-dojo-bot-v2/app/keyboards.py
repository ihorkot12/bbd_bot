"""
keyboards.py — Ukrainian inline та reply keyboards для pyTelegramBotAPI.

Усі тексти кнопок — українською мовою.
"""
from __future__ import annotations

from typing import List, Optional

from telebot import types


# ── Головні меню ──────────────────────────────────────────────────────────────

def main_menu_owner() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("💰 Оплати", callback_data="menu:payments"),
        types.InlineKeyboardButton("📋 Відвідуваність", callback_data="menu:attendance"),
        types.InlineKeyboardButton("➕ Додати", callback_data="ops:menu"),
        types.InlineKeyboardButton("👥 Учні", callback_data="menu:members"),
        types.InlineKeyboardButton("🔍 Ліди / Проби", callback_data="menu:leads"),
        types.InlineKeyboardButton("📅 Події", callback_data="menu:events"),
        types.InlineKeyboardButton("🎂 Дні народження", callback_data="menu:birthdays"),
        types.InlineKeyboardButton("📊 Дайджест", callback_data="menu:digest"),
        types.InlineKeyboardButton("🧭 Інструкція", callback_data="menu:ownerhelp"),
        types.InlineKeyboardButton("✉️ Шаблони", callback_data="menu:templates"),
        types.InlineKeyboardButton("⚙️ Налаштування", callback_data="menu:settings"),
    )
    return kb


def main_menu_admin() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("💰 Оплати", callback_data="menu:payments"),
        types.InlineKeyboardButton("📋 Відвідуваність", callback_data="menu:attendance"),
        types.InlineKeyboardButton("➕ Додати", callback_data="ops:menu"),
        types.InlineKeyboardButton("👥 Учні", callback_data="menu:members"),
        types.InlineKeyboardButton("🔍 Ліди / Проби", callback_data="menu:leads"),
        types.InlineKeyboardButton("📅 Події", callback_data="menu:events"),
        types.InlineKeyboardButton("🎂 Дні народження", callback_data="menu:birthdays"),
        types.InlineKeyboardButton("🧭 Інструкція", callback_data="menu:ownerhelp"),
        types.InlineKeyboardButton("✉️ Шаблони", callback_data="menu:templates"),
    )
    return kb


def main_menu_coach() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("📋 Відвідуваність", callback_data="menu:attendance"),
        types.InlineKeyboardButton("➕ Додати", callback_data="ops:menu"),
        types.InlineKeyboardButton("👥 Мої учні", callback_data="menu:members"),
        types.InlineKeyboardButton("🔍 Ліди", callback_data="menu:leads"),
        types.InlineKeyboardButton("📅 Події", callback_data="menu:events"),
        types.InlineKeyboardButton("🎂 Привітання ДН", callback_data="menu:birthdays"),
    )
    return kb


def main_menu_parent() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("💰 Моя оплата", callback_data="menu:my_payment"),
        types.InlineKeyboardButton("📋 Відвідуваність дитини", callback_data="menu:my_attendance"),
        types.InlineKeyboardButton("📅 Розклад / події", callback_data="menu:events"),
        types.InlineKeyboardButton("📞 Контакти", callback_data="menu:contact"),
    )
    return kb


def main_menu_guest() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("🥋 Запис на пробне", callback_data="menu:trial_request"),
        types.InlineKeyboardButton("📋 Реєстрація учасника", callback_data="menu:registration"),
        types.InlineKeyboardButton("📅 Розклад", callback_data="menu:schedule"),
        types.InlineKeyboardButton("💰 Вартість", callback_data="menu:price"),
        types.InlineKeyboardButton("📍 Адреса", callback_data="menu:address"),
        types.InlineKeyboardButton("📞 Контакти", callback_data="menu:contact"),
    )
    return kb


# ── Оплати ────────────────────────────────────────────────────────────────────

def payments_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("📊 Статус оплат", callback_data="pay:status"),
        types.InlineKeyboardButton("⚠️ Боржники", callback_data="pay:debtors"),
        types.InlineKeyboardButton("🔔 Надіслати нагадування", callback_data="pay:remind"),
        types.InlineKeyboardButton("✏️ Змінити статус", callback_data="pay:edit"),
    )
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="menu:back"))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def owner_operations_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("➕ Додати учасника покроково", callback_data="ops:add_member"),
        types.InlineKeyboardButton("🥋 Додати / редагувати групу покроково", callback_data="ops:add_group"),
        types.InlineKeyboardButton("👥 Редагувати учасників кнопками", callback_data="ops:edit_members"),
        types.InlineKeyboardButton("💰 Оновити оплату учасника", callback_data="ops:set_payment"),
        types.InlineKeyboardButton("🧭 Інструкція власника", callback_data="menu:ownerhelp"),
        types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"),
    )
    return kb


def wizard_cancel_keyboard() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("❌ Скасувати", callback_data="ops:cancel"),
        types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"),
    )
    return kb


def participant_type_keyboard() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("🧒 Дитина", callback_data="ops:ptype:child"),
        types.InlineKeyboardButton("👤 Дорослий", callback_data="ops:ptype:adult"),
    )
    kb.add(types.InlineKeyboardButton("❌ Скасувати", callback_data="ops:cancel"))
    return kb


def yes_no_keyboard(prefix: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("✅ Так", callback_data=f"{prefix}:yes"),
        types.InlineKeyboardButton("❌ Ні", callback_data=f"{prefix}:no"),
    )
    kb.add(types.InlineKeyboardButton("❌ Скасувати", callback_data="ops:cancel"))
    return kb


def member_list_keyboard(members: List, prefix: str = "ops:member") -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    for member in members[:30]:
        kb.add(types.InlineKeyboardButton(
            f"{member.full_name} ({member.member_id})",
            callback_data=f"{prefix}:{member.member_id}"
        ))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def member_edit_keyboard(member_id: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("🥋 Змінити групу", callback_data=f"ops:edit_member:{member_id}:group"),
        types.InlineKeyboardButton("📞 Змінити телефон", callback_data=f"ops:edit_member:{member_id}:phone"),
        types.InlineKeyboardButton("🎂 Перемкнути привітання ДН", callback_data=f"ops:edit_member:{member_id}:birthday"),
        types.InlineKeyboardButton("🚫 Активний / Неактивний", callback_data=f"ops:edit_member:{member_id}:active"),
        types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"),
    )
    return kb


def payment_status_keyboard(member_id: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    statuses = [
        ("✅ Сплачено", "paid"),
        ("💛 Частково", "partial"),
        ("❌ Не сплачено", "unpaid"),
        ("🤝 Обіцяно", "promised"),
        ("🔴 Прострочено", "overdue"),
        ("❄️ Заморожено", "frozen"),
    ]
    for label, status in statuses:
        kb.add(types.InlineKeyboardButton(
            label, callback_data=f"pay:set_status:{member_id}:{status}"
        ))
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="pay:status"))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


# ── Відвідуваність ────────────────────────────────────────────────────────────

def attendance_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("📝 Відмітити присутність", callback_data="att:mark"),
        types.InlineKeyboardButton("📊 Переглянути журнал", callback_data="att:view"),
        types.InlineKeyboardButton("⚠️ Незакриті журнали", callback_data="att:unclosed"),
        types.InlineKeyboardButton("😴 Неактивні учні", callback_data="att:inactive"),
    )
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="menu:back"))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def mark_attendance_keyboard(group_id: str, lesson_date: str,
                              members: List[dict]) -> types.InlineKeyboardMarkup:
    """
    Динамічна клавіатура для позначення кожного учня.
    members: список dict з ключами member_id, full_name, status (або None).
    """
    kb = types.InlineKeyboardMarkup(row_width=1)
    for m in members:
        mid = m["member_id"]
        name = m["full_name"]
        status = m.get("status")
        if status == "present":
            icon = "✅"
        elif status == "absent":
            icon = "❌"
        else:
            icon = "⬜"
        kb.add(types.InlineKeyboardButton(
            f"{icon} {name}",
            callback_data=f"att:toggle:{group_id}:{lesson_date}:{mid}"
        ))
    kb.add(
        types.InlineKeyboardButton(
            "💾 Зберегти і закрити", callback_data=f"att:close:{group_id}:{lesson_date}"
        )
    )
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def attendance_status_keyboard(group_id: str, lesson_date: str,
                                member_id: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=3)
    kb.add(
        types.InlineKeyboardButton(
            "✅ Присутній", callback_data=f"att:set:present:{group_id}:{lesson_date}:{member_id}"
        ),
        types.InlineKeyboardButton(
            "❌ Відсутній", callback_data=f"att:set:absent:{group_id}:{lesson_date}:{member_id}"
        ),
        types.InlineKeyboardButton(
            "📋 Поважна", callback_data=f"att:set:excused:{group_id}:{lesson_date}:{member_id}"
        ),
    )
    return kb


# ── Ліди / Проби ──────────────────────────────────────────────────────────────

def leads_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("📋 Список лідів", callback_data="lead:list"),
        types.InlineKeyboardButton("➕ Новий лід", callback_data="lead:new"),
        types.InlineKeyboardButton("📅 Проби сьогодні", callback_data="lead:trials_today"),
        types.InlineKeyboardButton("🔔 Надіслати нагадування", callback_data="lead:remind"),
    )
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="menu:back"))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def after_trial_keyboard(lead_id: str) -> types.InlineKeyboardMarkup:
    """Кнопки для власника/тренера після пробного тренування."""
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(
            "✅ Був присутній", callback_data=f"lead:trial_present:{lead_id}"
        ),
        types.InlineKeyboardButton(
            "❌ Не прийшов", callback_data=f"lead:trial_absent:{lead_id}"
        ),
        types.InlineKeyboardButton(
            "📅 Перенести", callback_data=f"lead:reschedule:{lead_id}"
        ),
        types.InlineKeyboardButton(
            "🎉 Зарахувати до клубу", callback_data=f"lead:convert:{lead_id}"
        ),
    )
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def confirm_convert_keyboard(lead_id: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("✅ Підтвердити", callback_data=f"lead:confirm_convert:{lead_id}"),
        types.InlineKeyboardButton("❌ Скасувати", callback_data=f"lead:list"),
    )
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


# ── Події ─────────────────────────────────────────────────────────────────────

def events_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("📋 Список подій", callback_data="evt:list"),
        types.InlineKeyboardButton("➕ Нова подія", callback_data="evt:new"),
        types.InlineKeyboardButton("📢 Оголошення", callback_data="evt:announce"),
        types.InlineKeyboardButton("🔔 Нагадування", callback_data="evt:remind"),
    )
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="menu:back"))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def event_audience_keyboard(event_id: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("👥 Всім учасникам", callback_data=f"evt:audience:all:{event_id}"),
        types.InlineKeyboardButton("👨‍👩‍👧 Батькам", callback_data=f"evt:audience:parents:{event_id}"),
        types.InlineKeyboardButton("🥋 Тренерам", callback_data=f"evt:audience:coaches:{event_id}"),
    )
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


# ── Підтвердження ─────────────────────────────────────────────────────────────

def confirm_keyboard(yes_data: str, no_data: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("✅ Так", callback_data=yes_data),
        types.InlineKeyboardButton("❌ Ні", callback_data=no_data),
    )
    return kb


# ── Навігація ────────────────────────────────────────────────────────────────

def back_button(callback: str = "menu:back") -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data=callback))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


def forms_menu(registration_url: str, trial_url: str) -> types.InlineKeyboardMarkup:
    """Дві окремі форми: повна реєстрація і швидкий запис на пробне."""
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("🥋 Запис на пробне тренування", url=trial_url),
        types.InlineKeyboardButton("📋 Повна реєстрація учасника", url=registration_url),
        types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"),
    )
    return kb


def birthday_moderation_keyboard(member_id: str, year: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("✅ Опублікувати в канал батьків", callback_data=f"bd:publish:{member_id}:{year}"),
        types.InlineKeyboardButton("✏️ Не публікувати / вручну змінити", callback_data=f"bd:skip:{member_id}:{year}"),
        types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"),
    )
    return kb


def pagination_keyboard(page: int, total_pages: int,
                         prefix: str) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=3)
    buttons = []
    if page > 0:
        buttons.append(types.InlineKeyboardButton(
            "◀️", callback_data=f"{prefix}:page:{page - 1}"
        ))
    buttons.append(types.InlineKeyboardButton(
        f"{page + 1}/{total_pages}", callback_data="noop"
    ))
    if page < total_pages - 1:
        buttons.append(types.InlineKeyboardButton(
            "▶️", callback_data=f"{prefix}:page:{page + 1}"
        ))
    kb.add(*buttons)
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


# ── Reply keyboards (постійні) ─────────────────────────────────────────────────

def request_contact_keyboard() -> types.ReplyKeyboardMarkup:
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    kb.add(types.KeyboardButton("📱 Поділитися контактом", request_contact=True))
    kb.add(types.KeyboardButton("❌ Скасувати"))
    return kb


def remove_keyboard() -> types.ReplyKeyboardRemove:
    return types.ReplyKeyboardRemove()


# ── Шаблони ───────────────────────────────────────────────────────────────────

def templates_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("📋 Список шаблонів", callback_data="tmpl:list"),
        types.InlineKeyboardButton("✏️ Редагувати", callback_data="tmpl:edit"),
        types.InlineKeyboardButton("🔄 Скинути до дефолтів", callback_data="tmpl:reset"),
    )
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="menu:back"))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb


# ── Налаштування ──────────────────────────────────────────────────────────────

def settings_menu() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("📅 Дні нагадувань про оплату", callback_data="set:pay_days"),
        types.InlineKeyboardButton("⏰ Час нагадування тренеру", callback_data="set:att_time"),
        types.InlineKeyboardButton("⏰ Дедлайн журналу", callback_data="set:att_deadline"),
        types.InlineKeyboardButton("📊 Час дайджесту", callback_data="set:digest_time"),
    )
    kb.add(types.InlineKeyboardButton("◀️ Назад", callback_data="menu:back"))
    kb.add(types.InlineKeyboardButton("🏠 Головне меню", callback_data="menu:back"))
    return kb
