"""
tests/test_digest.py — unit-тести для складання тексту дайджесту.
"""
import pytest
from datetime import date
from app.services.digest import build_digest_text, _weekday_ua


class TestBuildDigestText:

    BASE_ARGS = dict(
        new_leads_count=3,
        trials_today=[{"name": "Дитина1"}],
        trials_tomorrow=[{"name": "Дитина2"}, {"name": "Дитина3"}],
        overdue_count=2,
        unpaid_count=5,
        partial_count=1,
        promised_expired=[{"name": "Учень1"}],
        unclosed_journals=[{"group": "Група А"}],
        inactive_members=[{"name": "Неактивний"}],
        upcoming_events=[
            {"date": "25.05", "title": "Турнір"},
            {"date": "30.05", "title": "Атестація"},
        ],
        period="2026-05",
        today=date(2026, 5, 23),
    )

    def test_contains_header(self):
        text = build_digest_text(**self.BASE_ARGS)
        assert "Дайджест Black Bear Dojo" in text

    def test_contains_date(self):
        text = build_digest_text(**self.BASE_ARGS)
        assert "23.05.2026" in text

    def test_contains_leads_count(self):
        text = build_digest_text(**self.BASE_ARGS)
        assert "3" in text  # new_leads_count

    def test_contains_payment_info(self):
        text = build_digest_text(**self.BASE_ARGS)
        assert "Прострочено" in text
        assert "2" in text  # overdue_count
        assert "Не сплачено" in text
        assert "5" in text

    def test_contains_attendance_info(self):
        text = build_digest_text(**self.BASE_ARGS)
        assert "Відвідуваність" in text
        assert "Незакриті" in text

    def test_contains_events(self):
        text = build_digest_text(**self.BASE_ARGS)
        assert "Турнір" in text
        assert "Атестація" in text

    def test_no_events_when_empty(self):
        args = dict(self.BASE_ARGS)
        args["upcoming_events"] = []
        text = build_digest_text(**args)
        assert isinstance(text, str)

    def test_zero_counts(self):
        args = dict(self.BASE_ARGS)
        args.update(
            new_leads_count=0,
            trials_today=[],
            trials_tomorrow=[],
            overdue_count=0,
            unpaid_count=0,
            partial_count=0,
            promised_expired=[],
            unclosed_journals=[],
            inactive_members=[],
        )
        text = build_digest_text(**args)
        assert "Дайджест" in text
        assert isinstance(text, str)

    def test_period_formatted(self):
        text = build_digest_text(**self.BASE_ARGS)
        # period "2026-05" → "Травень 2026"
        assert "Травень" in text or "2026-05" in text or "05" in text


class TestWeekdayUa:
    def test_monday(self):
        assert _weekday_ua(date(2026, 5, 25)) == "Понеділок"

    def test_saturday(self):
        assert _weekday_ua(date(2026, 5, 23)) == "Субота"

    def test_sunday(self):
        assert _weekday_ua(date(2026, 5, 24)) == "Неділя"

    def test_friday(self):
        assert _weekday_ua(date(2026, 5, 22)) == "П'ятниця"
