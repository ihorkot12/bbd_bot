# Політика запуску без списань Google Cloud

Для Black Bear Dojo Bot V2 використовуються тільки Google Workspace API:

- Google Sheets API для таблиці операційної бази.
- Google Drive API тільки для доступу service account до файлів.
- Google Forms API для читання відповідей форми.

У цьому проєкті не потрібно створювати:

- Compute Engine VM.
- Cloud Run.
- Cloud Storage buckets.
- BigQuery datasets.
- Paid Google Cloud resources.
- Quota increase requests.

## Поточний безпечний режим

Поки service account не має доступу до таблиці та форми, бот працює з:

```env
DRY_RUN=true
```

Це означає, що бот відповідає в Telegram, але не робить реальних записів у Google Sheets.

## Для повного режиму без платних ресурсів

Потрібно тільки вручну видати доступ service account до вже створених Google-файлів:

```text
bbdbot@gen-lang-client-0723262863.iam.gserviceaccount.com
```

Дати доступ Editor до таблиці:

```text
https://docs.google.com/spreadsheets/d/101vNE0kgiKy-WfqYOKpjrgcWVtYtuceDP3xTAK9Mlrg/edit
```

І доступ до Google Form:

```text
https://docs.google.com/forms/d/e/1FAIpQLSesT2y1vreDee-V90xP66GaTEPFibCXuGI9czsOK6iqg0HpYA/viewform
```

Після цього можна перемкнути:

```env
DRY_RUN=false
```

## Чого не робити

- Не прив'язувати billing account, якщо Google попросить оплату для інших сервісів.
- Не створювати VM або Cloud Run у Google Cloud для цього етапу.
- Не запитувати збільшення квот.
- Не вмикати додаткові API, які не потрібні для Sheets/Forms.
