# Google credentials для Black Bear Dojo Bot V2

Цей файл потрібен для останнього кроку запуску: дати боту право читати й записувати Google Таблицю.

## Навіщо це потрібно

Telegram token дозволяє боту писати в Telegram. Google credentials дозволяють боту працювати з Google Sheets: читати оплати, записувати відвідуваність, створювати ліди, вести логи й формувати зведення.

## Що вже готово

- Google Таблиця: https://docs.google.com/spreadsheets/d/101vNE0kgiKy-WfqYOKpjrgcWVtYtuceDP3xTAK9Mlrg/edit
- Google Form: https://docs.google.com/forms/d/e/1FAIpQLSesT2y1vreDee-V90xP66GaTEPFibCXuGI9czsOK6iqg0HpYA/viewform
- Trial Form: https://docs.google.com/forms/d/e/1FAIpQLSc7hWokYpbwC8JnY-VlHgwEcJGsOPBz-xf0aQeepQDWMwHkMA/viewform
- `OWNER_TELEGRAM_ID=329214126`
- `SPREADSHEET_ID=101vNE0kgiKy-WfqYOKpjrgcWVtYtuceDP3xTAK9Mlrg`
- `REGISTRATION_FORM_ID=1rdsZwpIY93fdXtd5e8-hnfn9Si7bt0fNtmKlfLlZCO8`

## Як створити credentials.json

1. Відкрийте Google Cloud Console: https://console.cloud.google.com/
2. Створіть або виберіть проєкт для Black Bear Dojo.
3. Увімкніть API:
   - Google Sheets API
   - Google Drive API
   - Google Forms API, якщо плануєте читати відповіді напряму через Forms API
4. Перейдіть у IAM & Admin → Service Accounts.
5. Створіть Service Account, наприклад `black-bear-dojo-bot`.
6. Відкрийте створений Service Account → Keys → Add key → Create new key → JSON.
7. Завантажений файл перейменуйте на `credentials.json`.
8. Покладіть `credentials.json` у корінь проєкту поруч із `.env`.
9. Скопіюйте email service account із JSON-файлу або з Google Cloud Console.
10. Відкрийте таблицю Black Bear Dojo і натисніть Share.
11. Додайте email service account із правами Editor.
12. Відкрийте обидві Google Forms і додайте цей самий service account як редактора, якщо хочете, щоб бот автоматично читав відповіді через Forms API.

## Після цього

У `.env` мають бути такі значення:

```env
TELEGRAM_BOT_TOKEN=ваш_токен_від_BotFather
OWNER_TELEGRAM_ID=329214126
SPREADSHEET_ID=101vNE0kgiKy-WfqYOKpjrgcWVtYtuceDP3xTAK9Mlrg
REGISTRATION_FORM_ID=1rdsZwpIY93fdXtd5e8-hnfn9Si7bt0fNtmKlfLlZCO8
TIMEZONE=Europe/Kyiv
GOOGLE_CREDENTIALS_FILE=credentials.json
```

Потім виконайте:

```bash
python scripts/bootstrap_sheets.py
python -m app.main
```

## Важливо про безпеку

Не відправляйте `credentials.json` у Telegram, GitHub або публічні чати. Не комітьте цей файл у репозиторій. У `.gitignore` він уже виключений.
